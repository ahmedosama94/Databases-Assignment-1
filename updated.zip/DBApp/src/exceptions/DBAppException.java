package exceptions;

public class DBAppException extends Exception {

}
